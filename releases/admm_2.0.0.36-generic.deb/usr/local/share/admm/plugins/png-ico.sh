#!/bin/bash
# Convert with imkagemadick
INF=icon.png
OUT=favicon.ico
if [ ! "$1" == "" ]; then
    INF=$1
fi
convert -resize x16 -gravity center -crop 16x16+0+0 $INF -flatten -colors 256 -background iconsparent $OUT
