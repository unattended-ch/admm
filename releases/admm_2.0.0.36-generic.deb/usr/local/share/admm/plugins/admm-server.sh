#!/bin/bash
EXCLUDE=""
if [ ! "$1" == "" ]; then
    PWD=$1
fi
SRC=scripts
if [ ! "$2" == "" ]; then
    SRC=$2
fi
if [ ! "$3" == "" ]; then
    URL=$3
else
    exit 1
fi
if [ "$(basename $URL)" == "" ]; then
    exit 1
fi
. $PWD/scripts/debian/functions.inc
pushd $PWD
    wget -T 3 -t 1 $URL >/dev/null 2>/dev/null
    if [ -f "$(basename $URL)" ]; then
        if [ "$SRC" == "scripts" ]; then
            tar -xzf $(basename $URL) -C $PWD/scripts/debian $EXCLUDE > /dev/null
            rm -f $(basename $URL)
        fi
        if [ "$SRC" == "plugins" ]; then
            tar -xzf $(basename $URL) -C $PWD/plugins $EXCLUDE > /dev/null
            rm -f $(basename $URL)
        fi
    fi
popd
