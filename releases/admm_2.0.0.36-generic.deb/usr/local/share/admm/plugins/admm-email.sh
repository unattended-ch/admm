#!/bin/bash
. $PWD/scripts/debian/functions.inc
if [ ! "$1" == "" ]; then
    INFORM=$1
fi
set_now
pushd $PWD
    if [ ! "$INFORM" == "" ]; then
        if [ -f "$PWD/output.log" ]; then
            printf "Send email to [$INFORM] with file [$PWD/output.log]\n"
            send_email "$INFORM" "admm Tasks [$NOW]" "$(cat $PWD/output.log)"
            rm -f $PWD/output.log
        else
            echo "[$PWD/output.log] not exists..."
        fi
    else
        printf "No email recipient specified in INFORM !\n"
    fi
popd
