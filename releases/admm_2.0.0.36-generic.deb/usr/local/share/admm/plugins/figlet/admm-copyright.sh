#!/bin/bash
PWD=../..
if [ ! "$1" == "" ]; then
    PWD=$1
fi
if [ ! -d "$PWD/plugins/logo" ]; then
    mkdir -p $PWD/plugins/logo
fi
$PWD/plugins/figlet/figlet -t -d "$PWD/plugins/figlet/fonts" -f "standard" "$2" > $PWD/plugins/logo/banner.logo
exit 0
