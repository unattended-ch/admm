#!/bin/bash
. $INC
DST=/var/www/repo/amd64
NAM=admm
EXCLUDE="--exclude='*.tar.gz' --exclude='*.bak' --exclude='*.*.bak' --exclude='*.zip' --exclude='${NAM}/tools/*' --exclude='${NAM}/backup/*.*.bak' --exclude='${NAM}/bak/*' --exclude='${NAM}/lib/*' --exclude='${NAM}/github/*'"
FILES="*"
OWN=www-data
pushd $SWD
    HEADER "Create [$DST/${NAM}-scripts.tar.gz]"
    sudo tar $EXCLUDE --exclude='index.conf' -cvzf $DST/${NAM}-scripts.tar.gz $FILES
    sudo tar -cvzf $DST/${NAM}-config.tar.gz index.conf
    sudo chown -v $OWN.$OWN $DST/${NAM}-*.tar.gz
popd
