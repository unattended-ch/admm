#!/bin/bash
FNT=smslant
PWD=../..
if [ ! "$1" == "" ]; then
    PWD=$1
fi
if [ ! -d "$PWD/plugins/logo" ]; then
    mkdir -p $PWD/plugins/logo
fi
HOST=$(hostname)
if [ "$HOST" == "nathan.imm.ch" ]; then
    FNT=slant
fi
if [ "$HOST" == "master.imm.ch" ]; then
    FNT=slant
fi
if [ "$HOST" == "enterprise.galaxy.lan" ]; then
    FNT=slant
fi
LEN=${#HOST}
if (( $LEN > 22 )); then
    HOST=${HOST:0:22}
fi
#echo "$HOST"
$PWD/plugins/figlet/figlet -t -d "$PWD/plugins/figlet/fonts" -f "$FNT" "$HOST" > $PWD/plugins/logo/hostname.logo
exit 0
