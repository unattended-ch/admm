#!/bin/bash
PWD=../..
if [ ! "$1" == "" ]; then
    PWD=$1
fi
if [ ! -d "$PWD/plugins/logo" ]; then
    mkdir -p $PWD/plugins/logo
fi
if [ ! -f "$PWD/plugins/logo/standard.logo" ]; then
    SHORT="$(echo $2 | cut -d' ' -f1) $(echo $2 | cut -d' ' -f2)"
    $PWD/plugins/figlet/figlet -t -d "$PWD/plugins/figlet/fonts" -f "standard" "$SHORT" > $PWD/plugins/logo/standard.logo
fi
$PWD/plugins/figlet/figlet -t -d "$PWD/plugins/figlet/fonts" -f "standard" "$2" > $PWD/plugins/logo/version.logo
exit 0
