#!/bin/bash
FILES=$(ls fonts/*.flf)
#FILES="$FILES $(ls fonts/*.flc)"
for var in $FILES; do
    #OUT="images/${var%%.*}.logo"
    OUT="logo.logo"
    echo "${var%%.*}" >> $OUT
    ./figlet -t -d "./fonts" -f "$var" $(cat ./logo.txt) >> $OUT
    cat $OUT
done
